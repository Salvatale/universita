1. per forma di Skolem si intende quekl metodo di risoluzione che può essere applicato per studiare la soddisfacibilità di un insieme generico di proposizioni.
2. NON DICE NULLA A RIGUARDO