# Cosa c'è dentro `EXERCISES`?
Gli esercizi svolti in coordinazione con il Prof. nella giornata 28/03/2023 dalle ore 14:30 alle ore 18:30. Gli esercizi sono stati presentati in prove d'esame passate.

Se notate errori o imprecisioni, segnalatele nell'apposito tab "Issues".