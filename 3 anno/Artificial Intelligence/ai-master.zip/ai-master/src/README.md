# Cosa contiene la cartella `src`?
Contiene quei file che possono essere utili per la comprensione degli esercizi, in particolare, per la generazione di grafici in spazio $\mathbb{R}^3$. In ciascun file, trovate commenti sulle linee di codice più importanti e i comandi necessari per compilare.

Se volete aggiungere file o proporre modifiche, fatelo con "Pull request" o "Issue" negli appositi TABs.