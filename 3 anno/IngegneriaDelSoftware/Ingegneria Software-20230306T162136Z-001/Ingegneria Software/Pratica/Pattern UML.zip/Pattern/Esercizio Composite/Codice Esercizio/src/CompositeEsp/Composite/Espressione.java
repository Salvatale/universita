package CompositeEsp.Composite;

import CompositeEsp.Numero.NumeroIntero;

public interface Espressione { // --> Component
	public NumeroIntero operation();
}
