package CompositeEsp.Numero;

public interface NumeroIntero {
	public int getValore();
	public NumeroIntero somma(NumeroIntero n);
	public NumeroIntero prodotto(NumeroIntero n);
}
