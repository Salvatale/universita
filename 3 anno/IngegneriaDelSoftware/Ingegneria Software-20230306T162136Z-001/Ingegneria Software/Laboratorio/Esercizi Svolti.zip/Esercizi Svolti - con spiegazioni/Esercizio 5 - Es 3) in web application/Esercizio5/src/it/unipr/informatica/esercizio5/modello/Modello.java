package it.unipr.informatica.esercizio5.modello;

import java.util.List;

public interface Modello {
	public boolean aggiornaCognome(Studente studente, String cognome);

	public boolean aggiornaNome(Studente studente, String nome);

	public Studente aggiornaStudente(Studente studente) throws ModelloException;

	public Studente leggiStudente(int matricola) throws ModelloException;

	public Studente aggiungiStudente(String cognome, String nome) throws ModelloException;

	public List<Studente> ricaricaStudenti() throws ModelloException;

	public void rimuoviStudente(int matricola) throws ModelloException;
}
