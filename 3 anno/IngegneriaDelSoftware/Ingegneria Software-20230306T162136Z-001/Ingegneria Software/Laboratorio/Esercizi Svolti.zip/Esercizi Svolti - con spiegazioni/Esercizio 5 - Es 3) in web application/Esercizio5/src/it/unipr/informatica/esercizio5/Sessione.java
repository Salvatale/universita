package it.unipr.informatica.esercizio5;

import it.unipr.informatica.esercizio5.database.DatabaseManager;

public class Sessione {
	protected DatabaseManager databaseManager;
	
	public Sessione() {
		databaseManager = new DatabaseManager();
	}
	
	public DatabaseManager getDatabaseManager() {
		return databaseManager;
	}
}
