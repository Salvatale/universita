package it.unipr.informatica.esercizio7.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import it.unipr.informatica.esercizio7.modello.Modello;
import it.unipr.informatica.esercizio7.modello.ModelloException;
import it.unipr.informatica.esercizio7.modello.Studente;

public class DatabaseManager implements Modello {
	protected String url;
	
	public DatabaseManager() {
		try {
			ResourceBundle bundle = ResourceBundle.getBundle("configurazione");
			
			String clazz = bundle.getString("database.class");
			
			url = bundle.getString("database.url");

			Class.forName(clazz);
		} catch(Throwable throwable) {
			throwable.printStackTrace();
		}
	}
	
	@Override
	public boolean aggiornaCognome(Studente studente, String cognome) {
		Connection connessione = null;
		
		PreparedStatement statement = null;
		
		try {
			connessione = connetti();
			
			statement = connessione.prepareStatement("UPDATE STUDENTI SET COGNOME = ? WHERE MATRICOLA = ?");
			
			statement.setString(1, cognome);

			statement.setInt(2, studente.getMatricola());

			statement.execute();
		} catch(Throwable throwable) {
			throwable.printStackTrace();
			
			disconnetti(connessione, statement, null);

			return false;
		}
		
		disconnetti(connessione, statement, null);
		
		return true;
	}

	@Override
	public boolean aggiornaNome(Studente studente, String nome) {
		Connection connessione = null;
		
		PreparedStatement statement = null;
		
		try {
			connessione = connetti();
			
			statement = connessione.prepareStatement("UPDATE STUDENTI SET NOME = ? WHERE MATRICOLA = ?");
			
			statement.setString(1, nome);

			statement.setInt(2, studente.getMatricola());

			statement.execute();
		} catch(Throwable throwable) {
			throwable.printStackTrace();
			
			disconnetti(connessione, statement, null);

			return false;
		}
		
		disconnetti(connessione, statement, null);
		
		return true;
	}
	
	@Override
	public Studente aggiornaStudente(Studente studente) throws ModelloException {
		Connection connessione = null;
		
		PreparedStatement statement = null;
				
		try {
			connessione = connetti();
			
			statement = connessione.prepareStatement("UPDATE STUDENTI SET COGNOME = ?, NOME = ? WHERE MATRICOLA = ?");

			statement.setString(1, studente.getCognome());

			statement.setString(2, studente.getNome());
			
			statement.setInt(3, studente.getMatricola());

			statement.execute();

		} catch(Throwable throwable) {
			throwable.printStackTrace();
			
			disconnetti(connessione, statement, null);

			throw new ModelloException("Impossibile aggiornare lo studente con matricola " + studente.getMatricola() + ", cognome " + studente.getCognome() + " e nome " + studente.getNome());
		}
		
		disconnetti(connessione, statement, null);
		
		return studente;
	}

	@Override
	public void rimuoviStudente(int matricola) throws ModelloException {
		Connection connessione = null;
		
		PreparedStatement statement = null;
		
		try {
			connessione = connetti();
			
			statement = connessione.prepareStatement("DELETE FROM STUDENTI WHERE MATRICOLA = ?");
			
			statement.setInt(1, matricola);

			statement.execute();
		} catch(Throwable throwable) {
			throwable.printStackTrace();
			
			disconnetti(connessione, statement, null);

			throw new ModelloException("Impossibile rimuovere lo studente");
		}
		
		disconnetti(connessione, statement, null);
	}
	
	@Override
	public List<Studente> ricaricaStudenti() throws ModelloException {
		List<Studente> risultato = new ArrayList<Studente>();

		Connection connessione = null;
		
		PreparedStatement statement = null;
		
		ResultSet resultSet = null;
		
		try {
			connessione = connetti();
			
			statement = connessione.prepareStatement("SELECT * FROM STUDENTI");
			
			resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				int matricola = resultSet.getInt("MATRICOLA");

				String cognome = resultSet.getString("COGNOME");

				String nome = resultSet.getString("NOME");
				
				Studente studente = new Studente(matricola, cognome, nome);
				
				risultato.add(studente);
			}			
		} catch(Throwable throwable) {
			throwable.printStackTrace();
			
			disconnetti(connessione, statement, resultSet);

			throw new ModelloException("Impossibile ricaricare la tabella");
		}
		
		disconnetti(connessione, statement, resultSet);
		
		return risultato;
	}

	@Override
	public Studente leggiStudente(int matricola) throws ModelloException {
		Connection connessione = null;
		
		PreparedStatement statement = null;
		
		ResultSet resultSet = null;
		
		Studente risultato = null;
		
		try {
			connessione = connetti();
			
			statement = connessione.prepareStatement("SELECT * FROM STUDENTI WHERE MATRICOLA = ?");

			statement.setInt(1, matricola);
			
			resultSet = statement.executeQuery();
			
			if(resultSet.next()) {
				String cognome = resultSet.getString("COGNOME");

				String nome = resultSet.getString("NOME");
				
				risultato = new Studente(matricola, cognome, nome);
			}			
		} catch(Throwable throwable) {
			throwable.printStackTrace();
			
			disconnetti(connessione, statement, resultSet);

			throw new ModelloException("Impossibile leggere lo studente con matricola " + matricola);
		}
		
		disconnetti(connessione, statement, resultSet);
		
		return risultato;
	}

	@Override
	public Studente aggiungiStudente(String cognome, String nome) throws ModelloException {
		Connection connessione = null;
		
		PreparedStatement statement = null;
		
		ResultSet resultSet = null;
		
		Studente risultato = null;
		
		try {
			connessione = connetti();
			
			statement = connessione.prepareStatement("INSERT INTO STUDENTI (COGNOME, NOME) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);

			statement.setString(1, cognome);

			statement.setString(2, nome);
			
			statement.execute();

			resultSet = statement.getGeneratedKeys();
			
			if(resultSet.next()) {
				int matricola = resultSet.getInt(1);

				risultato = new Studente(matricola, cognome, nome);
			}			
		} catch(Throwable throwable) {
			throwable.printStackTrace();
			
			disconnetti(connessione, statement, resultSet);

			throw new ModelloException("Impossibile aggiungere lo studente con cognome " + cognome + " e nome " + nome);
		}
		
		disconnetti(connessione, statement, resultSet);
		
		return risultato;
	}

	protected Connection connetti() throws SQLException {
		return DriverManager.getConnection(url);
	}
	
	protected void disconnetti(Connection connessione, Statement statement, ResultSet resultSet) {
		try {
			resultSet.close();
		} catch(Throwable throwable) {
			// Vuoto
		}

		try {
			statement.close();
		} catch(Throwable throwable) {
			// Vuoto
		}

		try {
			connessione.close();
		} catch(Throwable throwable) {
			// Vuoto
		}
	}
}
