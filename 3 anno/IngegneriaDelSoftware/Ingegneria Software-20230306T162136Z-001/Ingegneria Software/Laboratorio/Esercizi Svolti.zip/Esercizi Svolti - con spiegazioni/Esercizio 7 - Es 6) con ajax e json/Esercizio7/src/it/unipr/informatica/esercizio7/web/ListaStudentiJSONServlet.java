package it.unipr.informatica.esercizio7.web;

import it.unipr.informatica.esercizio7.Sessione;
import it.unipr.informatica.esercizio7.database.DatabaseManager;
import it.unipr.informatica.esercizio7.modello.Studente;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
public class ListaStudentiJSONServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
		
			Sessione sessione = (Sessione)session.getAttribute("sessione");

			if(sessione == null) {
				sessione = new Sessione();
			
				session.setAttribute("sessione", sessione);
			}

			DatabaseManager databaseManager = sessione.getDatabaseManager();
		
			List<Studente> studenti = databaseManager.ricaricaStudenti();
			
			response.setContentType("text/plain");
			
			String risultato = "{ ";

			int indice = 0;
			
			for (Studente studente : studenti) {
				risultato += "'" + indice + "' : {";
				
				risultato += "'matricola' : '" + studente.getMatricola() + "', ";

				risultato += "'cognome' : '" + studente.getCognome() + "', ";

				risultato += "'nome' : '" + studente.getNome() + "'";

				risultato += " }";
				
				indice++;
				
				if(indice < studenti.size())
					risultato += ", ";
			}
			
			risultato += " }";
			
			System.out.println(risultato);
			
			PrintWriter out = response.getWriter();
			
			out.println(risultato);
			
			out.flush();
		} catch(Throwable throwable) {
			request.getRequestDispatcher("errore.html").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
