package it.unipr.informatica.esercizio7;

import it.unipr.informatica.esercizio7.database.DatabaseManager;

public class Sessione {
	protected DatabaseManager databaseManager;
	
	public Sessione() {
		databaseManager = new DatabaseManager();
	}
	
	public DatabaseManager getDatabaseManager() {
		return databaseManager;
	}
}
