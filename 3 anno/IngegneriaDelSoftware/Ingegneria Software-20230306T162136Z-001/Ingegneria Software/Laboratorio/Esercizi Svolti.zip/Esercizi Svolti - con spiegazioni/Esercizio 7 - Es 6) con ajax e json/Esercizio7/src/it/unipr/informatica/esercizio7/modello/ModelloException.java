package it.unipr.informatica.esercizio7.modello;

@SuppressWarnings("serial")
public class ModelloException extends Exception {
	public ModelloException(String messaggio) {
		super(messaggio);
	}
	
	public ModelloException(Exception origine) {
		super(origine);
	}
}
