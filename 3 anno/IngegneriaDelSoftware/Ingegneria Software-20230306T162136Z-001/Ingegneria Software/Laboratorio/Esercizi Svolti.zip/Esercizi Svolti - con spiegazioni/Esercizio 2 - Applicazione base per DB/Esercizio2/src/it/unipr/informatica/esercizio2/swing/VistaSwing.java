package it.unipr.informatica.esercizio2.swing;

import it.unipr.informatica.esercizio2.Applicazione;
import it.unipr.informatica.esercizio2.modello.Modello;
import it.unipr.informatica.esercizio2.modello.Studente;
import it.unipr.informatica.esercizio2.vista.Vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URL;
import java.util.List;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.table.TableModel;

import com.sun.glass.events.KeyEvent;

public class VistaSwing implements Vista {
	protected Applicazione applicazione;
	
	protected JTable tabella;
	
	protected JFrame finestra;
	
	protected Icon iconaAggiorna;
	
	protected Modello modello;
	
	public VistaSwing(Applicazione applicazione) {
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch(Throwable throwable) {
			// Vuoto
		}

		this.applicazione = applicazione;

		this.modello = applicazione.getModello();
		
		this.tabella = new JTable();

		tabella.setModel(new ModelloTabella(modello));
		
		URL url = getClass().getResource("/aggiorna.gif");
			
		if(url != null)
			iconaAggiorna = new ImageIcon(url);
		else
			iconaAggiorna = null;
	}
	
	@Override
	public void apriFinestraPrincipale() {
		JButton bottone = new JButton();
		
		bottone.setText("Aggiorna Tabella");

		bottone.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				aggiornaTabella();
			}
		});
		
		JPanel pannelloInBasso = new JPanel();
		
		pannelloInBasso.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		pannelloInBasso.add(bottone);

		// TODO mettere icona
		JButton toolAggiornaTabella;
		
		if(iconaAggiorna == null)
			toolAggiornaTabella = new JButton("Aggiorna Tabella");
		else
			toolAggiornaTabella = new JButton(iconaAggiorna);
			
		toolAggiornaTabella.setFocusable(false);
		
		toolAggiornaTabella.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evento) {
				aggiornaTabella();
			}
		});
		
		JToolBar toolBar = new JToolBar("Sistema di Gestione Studenti");
		
		toolBar.add(toolAggiornaTabella);
		
		JPanel pannelloPrincipale = new JPanel();
		
		pannelloPrincipale.setLayout(new BorderLayout());

		pannelloPrincipale.add(toolBar, BorderLayout.NORTH);
		
		pannelloPrincipale.add(pannelloInBasso, BorderLayout.SOUTH);
		
		pannelloPrincipale.add(new JScrollPane(tabella), BorderLayout.CENTER);
		
		JMenuItem aggiornaTabellaMenuItem = new JMenuItem("Aggiorna tabella");
		aggiornaTabellaMenuItem.setMnemonic(KeyEvent.VK_A);		
		aggiornaTabellaMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
		
		aggiornaTabellaMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evento) {
				aggiornaTabella();
			}
		});
		
		JMenu menuTabella = new JMenu("Tabella");
		menuTabella.setMnemonic(KeyEvent.VK_T);		
		menuTabella.add(aggiornaTabellaMenuItem);
		
		JMenuItem esciMenuItem = new JMenuItem("Esci");
		esciMenuItem.setMnemonic(KeyEvent.VK_E);				
		esciMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evento) {
				esci();
			}
		});
		
		JMenu menuFile = new JMenu("File");
		menuFile.setMnemonic(KeyEvent.VK_F);
		menuFile.add(esciMenuItem);
		
		JMenuBar menuBar = new JMenuBar();

		menuBar.add(menuFile);

		menuBar.add(menuTabella);

		finestra = new JFrame();
		
		finestra.getContentPane().add(pannelloPrincipale);
		
		finestra.setTitle("Sistema di Gestione Studenti");
		
		finestra.setBounds(0, 0, 600, 600);

		finestra.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		finestra.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent evento) {
				esci();
			}
		});
		
		finestra.setJMenuBar(menuBar);
		
		finestra.setVisible(true);
	}

	protected void aggiornaTabella() {
		try {
			List<Studente> dati = applicazione.ricaricaStudenti();
		
			TableModel modelloTabella = new ModelloTabella(modello, dati);
		
			tabella.setModel(modelloTabella);
		} catch(Throwable throwable) {
			errore("Impossibile aggiornare la tabella");
		}
	}
	
	protected void esci() {
		if(seiSicuro())
			applicazione.esci();
	}
	
	protected boolean seiSicuro() {
		int risposta = JOptionPane.showConfirmDialog(finestra, "Sei sicuro?", "Messaggio", JOptionPane.YES_NO_OPTION);

		return risposta == JOptionPane.OK_OPTION;
	}

	protected void errore(String messaggio) {
		JOptionPane.showMessageDialog(finestra, messaggio, "Errore", JOptionPane.ERROR_MESSAGE);
	}
}
