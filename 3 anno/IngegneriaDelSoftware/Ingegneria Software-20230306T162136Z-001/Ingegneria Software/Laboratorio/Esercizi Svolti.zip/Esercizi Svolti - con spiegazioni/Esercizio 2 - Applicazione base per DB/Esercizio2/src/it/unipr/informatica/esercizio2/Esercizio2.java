package it.unipr.informatica.esercizio2;

public class Esercizio2 {
	public static void main(String[] args) {
		new Applicazione().run();
	}
}
