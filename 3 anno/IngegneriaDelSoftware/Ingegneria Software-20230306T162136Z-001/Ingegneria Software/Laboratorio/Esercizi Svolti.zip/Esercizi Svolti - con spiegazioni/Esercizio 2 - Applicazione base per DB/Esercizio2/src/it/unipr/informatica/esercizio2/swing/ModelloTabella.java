package it.unipr.informatica.esercizio2.swing;

import it.unipr.informatica.esercizio2.modello.Modello;
import it.unipr.informatica.esercizio2.modello.Studente;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

public class ModelloTabella implements TableModel {
	protected List<Studente> dati;
	
	protected Modello modello;
	
	public ModelloTabella(Modello modello) {
		this.modello = modello;
		
		this.dati = new ArrayList<Studente>();
	}

	public ModelloTabella(Modello modello, List<Studente> dati) {
		this.modello = modello;

		this.dati = dati;
	}

	@Override
	public int getColumnCount() {
		return 3;
	}
	
	@Override
	public String getColumnName(int indice) {
		switch(indice) {
		case 0:
			return "Matricola";
		case 1:
			return "Cognome";
		case 2:
			return "Nome";
		default:
			throw new IllegalArgumentException("Argomento indice non valido: " + indice);	
		}
	}
	
	@Override
	public Class<?> getColumnClass(int indice) {
		switch(indice) {
		case 0:
			return int.class;
		case 1:
		case 2:
			return String.class;
		default:
			throw new IllegalArgumentException("Argomento indice non valido: " + indice);				
		}
	}
	
	@Override
	public boolean isCellEditable(int riga, int colonna) {
		if(colonna == 0)
			return false;
		
		return true;
	}

	@Override
	public void setValueAt(Object valore, int riga, int colonna) {
		Studente studente = dati.get(riga);
		
		if(colonna == 1) {
			String cognome = (String)valore;
			
			if(modello.aggiornaCognome(studente, cognome))
				studente.setCognome(cognome);
		} else {
			String nome = (String)valore;
			
			if(modello.aggiornaNome(studente, nome))
				studente.setNome(nome);
		}
	}

	@Override
	public int getRowCount() {
		return dati.size();
	}

	@Override
	public Object getValueAt(int riga, int colonna) {
		if(riga > dati.size() || riga < 0)
			throw new IllegalArgumentException("Argomento riga non valido: " + riga);				

		Studente studente = dati.get(riga);
		
		switch (colonna) {
		case 0:
			return studente.getMatricola();
		case 1:
			return studente.getCognome();
		case 2:
			return studente.getNome();
		default:
			throw new IllegalArgumentException("Argomento colonna non valido: " + colonna);	
		}
	}
	
	@Override
	public void addTableModelListener(TableModelListener listener) {
		// Vuoto
	}

	@Override
	public void removeTableModelListener(TableModelListener listener) {
		// Vuoto
	}
}
