package it.unipr.informatica.esercizio2;

import java.util.List;

import it.unipr.informatica.esercizio2.database.DatabaseManager;
import it.unipr.informatica.esercizio2.modello.Modello;
import it.unipr.informatica.esercizio2.modello.ModelloException;
import it.unipr.informatica.esercizio2.modello.Studente;
import it.unipr.informatica.esercizio2.swing.VistaSwing;
import it.unipr.informatica.esercizio2.vista.Vista;

public class Applicazione implements Runnable {
	protected Vista vista;
	
	protected Modello modello;
	
	@Override
	public void run() {
		modello = new DatabaseManager();
		
		vista = new VistaSwing(this);
		
		vista.apriFinestraPrincipale();
	}
	
	public Modello getModello() {
		return modello;
	}
	
	public void esci() {
		System.exit(0);
	}
	
	public List<Studente> ricaricaStudenti() throws ModelloException {
		return modello.ricaricaStudenti();
	}
}
