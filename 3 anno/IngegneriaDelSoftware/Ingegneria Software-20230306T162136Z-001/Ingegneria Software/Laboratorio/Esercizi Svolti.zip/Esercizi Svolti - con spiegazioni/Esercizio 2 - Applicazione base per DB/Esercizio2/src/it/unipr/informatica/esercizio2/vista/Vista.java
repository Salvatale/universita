package it.unipr.informatica.esercizio2.vista;

public interface Vista {
	public void apriFinestraPrincipale();
}
