package it.unipr.informatica.esercizio2.modello;

import java.util.List;

public interface Modello {
	public boolean aggiornaCognome(Studente studente, String cognome);

	public boolean aggiornaNome(Studente studente, String nome);

	public List<Studente> ricaricaStudenti() throws ModelloException;
}
