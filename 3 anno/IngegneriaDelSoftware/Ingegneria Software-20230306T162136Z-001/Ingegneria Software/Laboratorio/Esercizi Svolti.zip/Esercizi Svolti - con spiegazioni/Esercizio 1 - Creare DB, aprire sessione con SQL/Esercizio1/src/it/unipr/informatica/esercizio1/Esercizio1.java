package it.unipr.informatica.esercizio1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Esercizio1 {
	public static void main(String[] args) {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			
			Connection connection = DriverManager.getConnection("jdbc:derby://localhost/Ateneo");
			
			PreparedStatement statement = connection.prepareStatement("INSERT INTO STUDENTI (COGNOME, NOME) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);
			
			statement.setString(1, "Grigi");

			statement.setString(2, "Mario");

			statement.execute();
			
			ResultSet chiavi = statement.getGeneratedKeys();
			
			chiavi.next();
						
			int matricolaGenerata = chiavi.getInt(1);
			
			chiavi.close();

			System.out.println("Aggiunto nuovo studente con matricola: " + matricolaGenerata);

			statement.close();
			
			statement = connection.prepareStatement("SELECT * FROM STUDENTI WHERE COGNOME LIKE ?");
			
			String iniziale = "G";

			statement.setString(1, iniziale + "%");
			
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				int matricola = resultSet.getInt("MATRICOLA");
				
				String cognome = resultSet.getString("COGNOME");
				
				String nome = resultSet.getString("NOME");
				
				System.out.println(matricola + ", " + cognome + ", " + nome);
			}

			resultSet.close();
			
			statement.close();
			
			statement = connection.prepareStatement("DELETE FROM STUDENTI WHERE COGNOME = ?");
			
			statement.setString(1, "Grigi");
			
			statement.execute();
			
			statement.close();
			
			connection.close();
		} catch(Throwable throwable) {
			throwable.printStackTrace();
		}
	}
}
