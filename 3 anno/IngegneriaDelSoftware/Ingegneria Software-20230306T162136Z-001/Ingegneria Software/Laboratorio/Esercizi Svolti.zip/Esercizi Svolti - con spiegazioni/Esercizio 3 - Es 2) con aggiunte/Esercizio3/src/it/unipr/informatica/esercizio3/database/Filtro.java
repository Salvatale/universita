package it.unipr.informatica.esercizio3.database;

public interface Filtro<X> {
	public boolean applica(X valore);
}
