package it.unipr.informatica.esercizio3;

import java.util.List;

import it.unipr.informatica.esercizio3.database.DatabaseManager;
import it.unipr.informatica.esercizio3.database.Filtro;
import it.unipr.informatica.esercizio3.database.RecordStudenti;
import it.unipr.informatica.esercizio3.modello.Studente;

public class Esercizio3 {
	public static void main(String[] args) {
		try {
			DatabaseManager databaseManager = new DatabaseManager();
		
			List<Studente> studenti = databaseManager.leggiTabella(
					RecordStudenti.class,
					new Filtro<Studente>() {
						@Override
						public boolean applica(Studente valore) {
							String cognome = valore.getCognome();
							
							return cognome != null && cognome.startsWith("B");
						}
					});

			for(Studente studente : studenti) {
				System.out.println(studente.getMatricola() + " " + studente.getCognome() + " " + studente.getNome());
			}
		} catch(Throwable throwable) {
			throwable.printStackTrace();
		}
	}
}
