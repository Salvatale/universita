package it.unipr.informatica.esercizio3.database;

import it.unipr.informatica.esercizio3.modello.ModelloException;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class DatabaseManager {
	protected String url;
	
	public DatabaseManager() {
		try {
			ResourceBundle bundle = ResourceBundle.getBundle("configurazione");
			
			String clazz = bundle.getString("database.class");
			
			url = bundle.getString("database.url");

			Class.forName(clazz);
		} catch(Throwable throwable) {
			throwable.printStackTrace();
		}
	}
	
	public <X, Y extends X> List<X> leggiTabella(Class<Y> classe, Filtro<X> filtro) throws ModelloException {
		Connection connection = null;
		
		Statement statement = null;
		
		ResultSet resultSet = null;
		
		try {
			connection = connetti();
			
			String nomeClasse = classe.getSimpleName();
			
			String nomeTabella = nomeClasse.substring("Record".length());
			
			String sql = "SELECT * FROM " + nomeTabella;
			
			statement = connection.createStatement();
			
			resultSet = statement.executeQuery(sql);
			
			List<X> risultato = new ArrayList<X>();

			while(resultSet.next()) {
				X record = classe.newInstance();
				
				Method[] metodi = classe.getMethods();
				
				for (int i = 0; i < metodi.length; i++) {
					String nomeMetodo = metodi[i].getName();
					
					if(nomeMetodo.startsWith("set")) {
						String nomeCampo = nomeMetodo.substring("set".length());
						
						Object valore = resultSet.getObject(nomeCampo);
						
						metodi[i].invoke(record, valore);
					}
				}
				
				if(filtro.applica(record))
					risultato.add(record);
			}
			
			disconnetti(connection, statement, resultSet);
			
			return risultato;
		} catch(Exception exception) {
			exception.printStackTrace();

			disconnetti(connection, statement, resultSet);

			throw new ModelloException(exception);
		}
	}
	
	protected Connection connetti() throws SQLException {
		return DriverManager.getConnection(url);
	}
	
	protected void disconnetti(Connection connessione, Statement statement, ResultSet resultSet) {
		try {
			resultSet.close();
		} catch(Throwable throwable) {
			// Vuoto
		}

		try {
			statement.close();
		} catch(Throwable throwable) {
			// Vuoto
		}

		try {
			connessione.close();
		} catch(Throwable throwable) {
			// Vuoto
		}
	}
}
