package it.unipr.informatica.esercizio3.database;

import it.unipr.informatica.esercizio3.modello.Studente;

public class RecordStudenti implements Record, Studente {
	private int matricola;
	
	private String cognome;
	
	private String nome;

	public RecordStudenti() {
		// Vuoto
	}
	
	@Override
	public int getMatricola() {
		return matricola;
	}

	public void setMatricola(int matricola) {
		this.matricola = matricola;
	}

	@Override
	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	@Override
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
