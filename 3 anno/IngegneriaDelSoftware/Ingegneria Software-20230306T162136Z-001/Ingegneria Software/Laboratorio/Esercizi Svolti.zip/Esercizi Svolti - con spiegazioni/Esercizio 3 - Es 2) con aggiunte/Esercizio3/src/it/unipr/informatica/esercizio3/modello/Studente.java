package it.unipr.informatica.esercizio3.modello;

public interface Studente {
	public int getMatricola();
		
	public String getCognome();
	
	public String getNome();
}
