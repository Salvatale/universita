package unipr.aldo.prova;

import unipr.aldo.graphic.*;


public class prova_main {
	public static void main( String[] args) {
		GUI_prova G = new GUI_prova();
		G.setVisible(true);  //mostra la finestra
	}
}
