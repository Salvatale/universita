package it.unipr.informatica.esercizio4.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class ContatoreServlet extends HttpServlet {
	public static final String CONTATORE = "contatore_servlet.contatore";

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();

		if(session.getAttribute(CONTATORE) == null)
			session.setAttribute(CONTATORE, 1);

		int contatore = (int)session.getAttribute(CONTATORE);

		contatore++;

		session.setAttribute(CONTATORE, contatore);

		request.getRequestDispatcher("contatore.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
