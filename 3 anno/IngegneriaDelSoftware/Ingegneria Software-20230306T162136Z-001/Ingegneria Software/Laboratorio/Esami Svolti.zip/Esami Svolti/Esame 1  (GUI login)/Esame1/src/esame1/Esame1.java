package esame1;

import esame1.swing.ApplicazioneSwing;

public class Esame1 {

	public static void main(String[] args) {
		ApplicazioneSwing applicazione = new ApplicazioneSwing();
		applicazione.pannelloLogin();
	}

}
