package esame1.modello;

public interface Modello {
	public boolean cercaUtente(Utente utente);
}
