package esame3.modello;

import java.util.List;

public interface Modello {
	public List<Studente> ricaricaLista();
}
