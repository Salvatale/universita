package esame2.applicazione;

import esame2.vistaSwing.ApplicazioneSwing;

public class Esame2 {

	public static void main(String[] args) {
		ApplicazioneSwing finestra = new ApplicazioneSwing();
		finestra.pannelloStudenti();
	}

}
